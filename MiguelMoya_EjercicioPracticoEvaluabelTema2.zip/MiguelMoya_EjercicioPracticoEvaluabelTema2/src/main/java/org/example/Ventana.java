package org.example;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana extends JFrame {

    private JPanel panel1;
    private JTextArea textArea1;
    private JComboBox comboBox1;
    private JComboBox comboBox2;
    private JButton confirmarYGuardarButton;
    private JButton volverAtrasButton;
    private JTable table1;

    public Ventana(){

        confirmarYGuardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Has pulsado en Confirmar y Guardar, se registrara el usuario introducido");

                if (textArea1.getText()==null){
                    JOptionPane.showMessageDialog(null,"No hay ningun correo introducido");
                    //Abajo introdiciria el usuario a la tabla
                }
                if (comboBox1.getItemListeners()==null){
                   JOptionPane.showMessageDialog(null,"No hay ningun Pais seleccionado");
                   //Abajo introduciria el Pais a la tabla
                }
                if (comboBox2.getItemListeners()==null){
                   JOptionPane.showMessageDialog(null,"No hay ninguna plataforma seleccionada");
                   //Abajo introduciria la platforma a la tabla
                }

            }
        });

        volverAtrasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Has pulsado el boton de volver atras");

            }
        });


        setContentPane(panel1);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
